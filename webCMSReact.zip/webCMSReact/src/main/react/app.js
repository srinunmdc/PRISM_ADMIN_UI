import React, {Component} from 'react';
import Aux from 'react-aux';

import Cores from './components/cores/cores';
import Plugins from './components/plugins/plugins';
import Themes from './components/themes/themes';

class App extends Component {
    render() {
        return (
            <div id="exTab1" className="tab-container">
                <ul  className="nav nav-tabs">
                    <li className="active xtab"><a  href="#1a" data-toggle="tab">Cores</a></li>
                    <li className="xtab"><a href="#2a" data-toggle="tab">Plugins</a></li>
                    <li className="xtab"><a href="#3a" data-toggle="tab">Themes</a></li>
                </ul>

                <div className="tab-content clearfix">
                    <div className="tab-pane active" id="1a">
                        <Cores />
                    </div>
                    <div className="tab-pane" id="2a">
                        <Plugins />
                    </div>
                    <div className="tab-pane" id="3a">
                        <Themes />
                    </div>
                </div>
            </div>
        );
    }
}

export default App;