import axios from 'axios';

const axiosInstance = axios.create({
    baseURL: 'http://andev10wphge115.dca.diginsite.net:8080/wph/selfUpgrade',
    headers: {
        'Content-Type': 'application/json',
        'offeringId' : 'AdminPlatform'
    }
});

export default axiosInstance;