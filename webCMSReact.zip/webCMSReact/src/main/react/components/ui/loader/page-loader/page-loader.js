import React from 'react';
import Aux from 'react-aux';

import classes from './page-loader.css';
import Backdrop from '../../backdrop/backdrop';

const pageLoader = (props) => {
    let loaderClassesArr = ['loading', 'hide'];
    let backdrop = null;
    
    if(props.show) {
        loaderClassesArr = ['loading', 'show'];
        backdrop = <Backdrop />;
    }

    let loaderClasses = loaderClassesArr.join(' ');

    return (
        <Aux>
            <div className={loaderClasses}>
                <div className="loader"></div>
            </div>
            {backdrop}
        </Aux>
    )
}

export default pageLoader;