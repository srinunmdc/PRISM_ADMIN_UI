import React from 'react';
import Aux from 'react-aux';

import Backdrop from '../backdrop/backdrop';
import CoreForm from '../../forms/core-form/core-form';
import PluginForm from '../../forms/plugin-form/plugin-form';
import ThemeForm from '../../forms/theme-form/theme-form';
import classes from './modal.css';

const modal = (props) => {
    let modalClassesArr = ['modal', 'fade', 'form-modal'];
    let backdrop = null;
    let form = null;
    
    if(props.show) {
        modalClassesArr.push('in', 'show');
        backdrop = <Backdrop />;
    }

    let modalClasses = modalClassesArr.join(' ');

    if(props.formName == 'add-edit-core') {
        form = <CoreForm 
                    formHandler={props.modalFormHandler}
                    formAction={props.formAction}
                    coreData={props.coreData}
                />;
    }

    if(props.formName == 'add-edit-plugin') {
        form = <PluginForm 
                    formHandler={props.modalFormHandler}
                    formAction={props.formAction}
                    pluginData={props.pluginData}
                    resetForm={props.show}
                />;
    }

    if(props.formName == 'add-edit-theme') {
        form = <ThemeForm 
                    formHandler={props.modalFormHandler}
                    formAction={props.formAction}
                    themeData={props.themeData}
                    resetForm={props.show}
                />;
    }

    return (
        <Aux>
            <div className={modalClasses + ' ' + props.formName} id="modalExample2" tabIndex="-1" role="dialog" aria-labelledby="modalExample2">
                <div className="modal-dialog" role="document">
                    <div className="modal-content">
                        <div className="modal-header">
                            <button type="button" className="close" aria-label="Close" onClick={props.close}>
                                <span aria-hidden="true">{String.fromCharCode(215)}</span>
                            </button>
                            <h2 className="modal-title">{props.headerTxt}</h2>
                        </div>
                        <div className="modal-body">
                            {form}
                        </div>
                    </div>
                </div>
            </div>
            {backdrop}
        </Aux>
    )
}

export default modal;