import React from 'react';
import Aux from 'react-aux';

import Button from '../../button/button';
import Backdrop from '../../backdrop/backdrop';

const confirmModal = (props) => {
    let modalClassesArr = ['modal', 'fade'];
    let backdrop = null;

    if(props.show) {
        modalClassesArr.push('in', 'show');
        backdrop = <Backdrop />;
    }

    let modalClasses = modalClassesArr.join(' ');

    return (
        <Aux>
            <div className={modalClasses} id="modalExample3" tabIndex="-1" role="dialog" aria-labelledby="modalExample3">
                <div className="modal-dialog modal-lg" role="document">
                    <div className="modal-content">
                        <div className="modal-header">
                            <button type="button" className="close" aria-label="Close" onClick={props.close}>
                                <span aria-hidden="true">{String.fromCharCode(215)}</span>
                            </button>
                            <h2 className="modal-title">Are you sure?</h2>
                        </div>
                        <div className="modal-body">
                            <div className="di-callout xs-void">
                                This {props.content} will be deleted.
                            </div>
                        </div>
                        <div className="modal-footer">
                            <Button btnType="button"
                                btnName="Yes"
                                btnClass="btn btn-primary"
                                clickHandler={props.confirmHandler}
                            />
                            <Button btnType="button"
                                btnName="No"
                                btnClass="btn btn-secondary"
                                clickHandler={props.close}
                            />
                        </div>
                    </div>
                </div>
            </div>
            {backdrop}
        </Aux>
    )
}

export default confirmModal;