import React from 'react';
import Aux from 'react-aux';

const button = (props) => {
    let button;

    if(props.withIcon) {
        button = (
            <button type={props.btnType} className={props.btnClass} onClick={props.clickHandler}>
                <span className={"glyphicon glyphicon-" + props.icon} aria-hidden="true"></span>
                {" " + props.btnName}
            </button>
        );
    }
    else {
        button = (
            <button type={props.btnType} className={props.btnClass} onClick={props.clickHandler}>
                {props.btnName}
            </button>
        ); 
    }  

    return (
        <Aux>
            {button}
        </Aux>   
    );
}

export default button;