import React from 'react';

const tableHead = (props) => {
    return (
        <thead className="brand-type-a-bg-10p">
            <tr>
                {props.columns.map((col, i) => {
                    return <th key={i}>{col}</th>
                })}
            </tr>
        </thead>
    );
}

export default tableHead;