import React from 'react';
import Aux from 'react-aux';

const alert = (props) => {
    let alertBlock;

    if(props.dismissible) {
        alertBlock = (
            <div className={"media alert alert-dismissible alert-" + props.alertType}>
                <a href="#" className="close" onClick={props.closeHandler}>&times;</a>
                <div className="media-left"></div>
                <div className="media-body">
                    {props.alertMsg}
                </div>
            </div>
        )
    }
    else {
        alertBlock = (
            <div className={"media alert alert-" + props.alertType}>
                <div className="media-left"></div>
                <div className="media-body">
                    {props.alertMsg}
                </div>
            </div>
        )
    }

    return (
        <Aux>
            {alertBlock}
        </Aux>
    );
}

export default alert;