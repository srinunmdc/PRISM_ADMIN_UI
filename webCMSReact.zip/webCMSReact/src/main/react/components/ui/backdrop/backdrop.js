import React from 'react';

const backdrop = (props) => {
    return (
        <div className="modal-backdrop fade in"></div>
    );
}

export default backdrop;