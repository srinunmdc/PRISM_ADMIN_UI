import React, {Component} from 'react';
import { ExpansionPanel, ExpansionPanelSummary, ExpansionPanelDetails, withStyles } from '@material-ui/core';

import Button from '../ui/button/button';
import Thead from '../ui/table/table-head/table-head';
import Modal from '../ui/modal/modal';
import Alert from '../ui/alert/alert';
import ConfirmModal from '../ui/modal/confirm-modal/confirm-modal';
import PageLoader from '../ui/loader/page-loader/page-loader';
import axios from '../../axios';

const styles = theme => ({
    expansionPanelDetails: {
      display: 'block',
      padding: '0px 0px 0px 5px'
    },
    expansionPanelSummary: {
        padding: '0px 5px'
    },
    expansionPanelP: {
        padding: '0px !important',
        margin: '0px'
    },
    expansionPanel: {
        borderRadius: '0px !important'
    }
});

class themes extends Component {
    state = {
        modalShow: false,
        confirmModalShow: false,
        loader: false,
        data: [],
        error: '',
        themeAdded: false,
        errorAddingTheme: false,
        editTheme: false,
        editThemeData: [],
        themeEdited: false,
        errorEditingTheme: false,
        deleteTheme: false,
        deleteThemeId: null,
        themeDeleted: false,
        errorDeletingTheme: false,
        errorAddingDependency: false,
        resetForm: false
    }

    componentDidMount() {
        this.setState({
            loader: true
        });

        axios.get('/get/theme')
            .then((response) => {
                this.setState({
                    data: response.data,
                    loader: false
                })
            })
            .catch((error) => {
                this.setState({
                    error: "Error fetching data",
                    loader: false
                })
            });
    }

    themeColumns = [
        'Name', 
        'Type', 
        'Is Mandatory', 
        'Is Licence', 
        'Version', 
        'Risk', 
        'Min Version WP', 
        'Tested WP',
        'Is Dependent',
        'WP Package List',
        ' '
    ];

    modalOpenHandler = () => {
        this.setState({
            modalShow: true
        })
    };

    modalCloseHandler = () => {
        this.setState({
            modalShow: false,
            editTheme: false
        })
    };

    confirmModalOpenHandler = () => {
        this.setState({
            confirmModalShow: true
        })
    };

    confirmModalCloseHandler = () => {
        this.setState({
            confirmModalShow: false
        })
    };

    alertCloseHandler = () => {
        this.setState({
            themeAdded: false,
            errorAddingTheme: false,
            editTheme: false,
            themeEdited: false,
            errorEditingTheme: false,
            deleteTheme: false,
            themeDeleted: false,
            errorDeletingTheme: false
        })        
    }

    themeFormHandler = async (event, arrLength) => {
        event.preventDefault();
        this.setState({
            loader: true
        });

        let wpPackageList = [];
        let res;
        for(let i=0; i<arrLength; i++) {
            let dName = event.target['dName' + i].value;
            let dType = event.target['dType' + i].value;
            let dVersion = event.target['dVersion' + i].value;
            try {
                res = await axios.get('/get/' + dType + '/' + dName);
            }
            catch(err) {
                this.setState({
                    errorAddingDependency: true,
                    modalShow: false,
                    loader: false
                })
            }
            if(res.data.length > 1) {
                wpPackageList.push(res.data.filter((obj) => obj.version == dVersion)[0]);
            }
            else {
                wpPackageList.push(res.data);
            }
        }

        let newTheme = [{
            "name": event.target.name.value,
            "type": event.target.type.value,
            "isMandatory": event.target.isMandatory.checked ? 1 : 0,
            "isLicence": event.target.isLicence.checked ? 1 : 0,
            "version": event.target.version.value,
            "risk": event.target.risk.value,
            "minVersionWp": event.target.minVersionWp.value,
            "testedWp": event.target.testedWp.value,
            "isDependent": event.target.isDependent.checked ? 1 : 0,
            "wpPackageList": wpPackageList.length ? wpPackageList : null
        }];

        console.log(newTheme);

        if(this.state.editTheme) {
            console.log(event.target.id.value);

            axios.post('/post/theme', newTheme)
                .then(res => {
                    this.setState({
                        themeEdited: true,
                        editTheme: false,
                        modalShow: false,
                        loader: false
                    })
                })
                .catch((error) => {
                    this.setState({
                        errorEditingTheme: true,
                        editTheme: false,
                        modalShow: false,
                        loader: false
                    })
                });
        }
        else {
            axios.post('/post/theme', newTheme)
                .then(res => {
                    this.setState({
                        themeAdded: true,
                        modalShow: false,
                        loader: false
                    })
                })
                .catch((error) => {
                    this.setState({
                        errorAddingTheme: true,
                        modalShow: false,
                        loader: false
                    })
                });
        }
    }

    editHandler = (event) => {
        this.setState({
            loader: true
        });

        axios.get('/get/theme/' + event.target.id)
            .then((response) => {
                this.setState({
                    editTheme: true,
                    editThemeData: response.data,
                    modalShow: true,
                    loader: false
                })
            })
            .catch((error) => {
                this.setState({
                    error: "Error fetching data",
                    loader: false
                })
            });
    }

    deleteHandler = (event) => {
        this.setState({
            confirmModalShow: true,
            deleteTheme: true,
            deleteThemeId: event.target.id
        })
    }

    themeDeleteHandler = () => {
        this.setState({
            loader: true
        });

        console.log(this.state.deleteThemeId);
        axios.post('/post/theme1', this.state.deleteThemeId)
            .then((response) => {
                this.setState({
                    themeDeleted: true,
                    deleteTheme: false,
                    confirmModalShow: false,
                    loader: false
                })
            })
            .catch((error) => {
                this.setState({
                    errorDeletingTheme: true,
                    deleteTheme: false,
                    confirmModalShow: false,
                    loader: false
                })
            });        
    }

    render() {
        const { classes } = this.props;

        // Alert
        let alert = null;
        if(this.state.error != '') {
            alert = <Alert 
                        alertType="danger" 
                        alertMsg={this.state.error}
                        dismissible={false}
                    />
        }
        else if(this.state.errorAddingTheme) {
            alert = <Alert 
                        alertType="danger" 
                        alertMsg="Error: Failed to add new theme"
                        dismissible
                        closeHandler={this.alertCloseHandler}
                    />
        }
        else if(this.state.themeAdded) {
            alert = <Alert 
                        alertType="success" 
                        alertMsg="Success: Added new theme"
                        dismissible
                        closeHandler={this.alertCloseHandler}
                    />
        }
        else if(this.state.errorEditingTheme) {
            alert = <Alert 
                        alertType="danger" 
                        alertMsg="Error: Failed to update the theme"
                        dismissible
                        closeHandler={this.alertCloseHandler}
                    />
        }
        else if(this.state.themeEdited) {
            alert = <Alert 
                        alertType="success" 
                        alertMsg="Success: Updated the theme"
                        dismissible
                        closeHandler={this.alertCloseHandler}
                    />
        }
        else if(this.state.errorDeletingTheme) {
            alert = <Alert 
                        alertType="danger" 
                        alertMsg="Error: Failed to delete the theme"
                        dismissible
                        closeHandler={this.alertCloseHandler}
                    />
        }
        else if(this.state.themeDeleted) {
            alert = <Alert 
                        alertType="success" 
                        alertMsg="Success: Deleted the theme"
                        dismissible
                        closeHandler={this.alertCloseHandler}
                    />
        }
        else if(this.state.errorAddingDependency) {
            alert = <Alert 
                        alertType="danger" 
                        alertMsg="Error: Please verify the dependency values"
                        dismissible
                        closeHandler={this.alertCloseHandler}
                    />
        }
        else {
            alert = null;
        }

        // Form action
        let modalHeaderTxt = 'Add Theme';
        let themeFormAction = 'add'
        if(this.state.editTheme) {
            modalHeaderTxt = 'Edit Theme';
            themeFormAction = 'edit'
        }

        return (
            <div>
                <Button btnType="button"
                    btnName="Add" 
                    withIcon
                    icon="plus" 
                    btnClass="btn sm btn-secondary" 
                    clickHandler={this.modalOpenHandler}
                />
                <hr />
                {alert}
                <div className="row">
                    <div className="col-xs-12 table-responsive">
                        <table className="table">
                            <Thead columns={this.themeColumns} />
                            <tbody>
                                {this.state.data.map((obj) => {
                                    return (
                                        <tr key={obj.id}>
                                            <td>{obj.name}</td>
                                            <td>{obj.type}</td>
                                            <td>{obj.isMandatory}</td>
                                            <td>{obj.isLicence}</td>
                                            <td>{obj.version}</td>
                                            <td>{obj.risk}</td>
                                            <td>{obj.minVersionWp}</td>
                                            <td>{obj.testedWp}</td>
                                            <td>{obj.isDependent}</td>
                                            <td>
                                                {obj.wpPackageList ? obj.wpPackageList.map((ele, i) => {
                                                    return (
                                                        <ExpansionPanel key={i} className={classes.expansionPanel}>
                                                            <ExpansionPanelSummary className={classes.expansionPanelSummary}>
                                                                <p className={classes.expansionPanelP}><strong>Name: </strong>{ele.name}</p>
                                                            </ExpansionPanelSummary>
                                                            <ExpansionPanelDetails className={classes.expansionPanelDetails}>
                                                                <p className={classes.expansionPanelP}><strong>Type: </strong>{ele.type}</p>
                                                                <p></p>
                                                                <p className={classes.expansionPanelP}><strong>Version: </strong>{ele.version}</p>
                                                                <p></p>
                                                            </ExpansionPanelDetails>
                                                        </ExpansionPanel>
                                                    )
                                                }) : null}
                                            </td>
                                            <td>
                                                <a id={obj.id} onClick={this.editHandler}>Edit</a>
                                                <p></p>
                                                <a id={obj.id} onClick={this.deleteHandler}>Delete</a>
                                            </td>
                                        </tr>
                                    )
                                })}
                            </tbody>
                        </table>
                    </div>
                </div>
                <Modal
                    headerTxt={modalHeaderTxt}
                    show={this.state.modalShow}
                    close={this.modalCloseHandler}
                    modalFormHandler={this.themeFormHandler}
                    formName="add-edit-theme"
                    formAction={themeFormAction}
                    themeData={this.state.editThemeData}
                    resetForm={this.state.resetForm}
                />
                <ConfirmModal
                    show={this.state.confirmModalShow}
                    close={this.confirmModalCloseHandler}
                    content="theme"
                    confirmHandler={this.themeDeleteHandler}
                />
                <PageLoader show={this.state.loader} />
            </div>
        );        
    }
}

export default withStyles(styles)(themes);