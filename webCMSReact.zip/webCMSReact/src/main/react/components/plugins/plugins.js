import React, {Component} from 'react';
import { ExpansionPanel, ExpansionPanelSummary, ExpansionPanelDetails, withStyles } from '@material-ui/core';

import Button from '../ui/button/button';
import Thead from '../ui/table/table-head/table-head';
import Modal from '../ui/modal/modal';
import Alert from '../ui/alert/alert';
import ConfirmModal from '../ui/modal/confirm-modal/confirm-modal';
import PageLoader from '../ui/loader/page-loader/page-loader';
import axios from '../../axios';

const styles = theme => ({
    expansionPanelDetails: {
      display: 'block',
      padding: '0px 0px 0px 5px'
    },
    expansionPanelSummary: {
        padding: '0px 5px'
    },
    expansionPanelP: {
        padding: '0px !important',
        margin: '0px'
    },
    expansionPanel: {
        borderRadius: '0px !important'
    }
});

class plugins extends Component {
    state = {
        modalShow: false,
        confirmModalShow: false,
        loader: false,
        data: [],
        error: '',
        pluginAdded: false,
        errorAddingPlugin: false,
        editPlugin: false,
        editPluginData: [],
        pluginEdited: false,
        errorEditingPlugin: false,
        deletePlugin: false,
        deletePluginId: null,
        pluginDeleted: false,
        errorDeletingPlugin: false,
        errorAddingDependency: false,
        resetForm: false
    }

    componentDidMount() {
        this.setState({
            loader: true
        });

        axios.get('/get/plugin')
            .then((response) => {
                this.setState({
                    data: response.data,
                    loader: false
                })
            })
            .catch((error) => {
                this.setState({
                    error: "Error fetching data",
                    loader: false
                })
            });
    }

    pluginColumns = [
        'Name', 
        'Type', 
        'Is Mandatory', 
        'Is Licence', 
        'Version', 
        'Risk', 
        'Min Version WP', 
        'Tested WP',
        'Is Dependent',
        'WP Package List',
        ' '
    ];

    modalOpenHandler = () => {
        this.setState({
            modalShow: true
        })
    };

    modalCloseHandler = () => {
        this.setState({
            modalShow: false,
            editPlugin: false
        })
    };

    confirmModalOpenHandler = () => {
        this.setState({
            confirmModalShow: true
        })
    };

    confirmModalCloseHandler = () => {
        this.setState({
            confirmModalShow: false
        })
    };

    alertCloseHandler = () => {
        this.setState({
            pluginAdded: false,
            errorAddingPlugin: false,
            editPlugin: false,
            pluginEdited: false,
            errorEditingPlugin: false,
            deletePlugin: false,
            pluginDeleted: false,
            errorDeletingPlugin: false
        })        
    }

    pluginFormHandler = async (event, arrLength) => {
        event.preventDefault();
        this.setState({
            loader: true
        });

        let wpPackageList = [];
        let res;
        for(let i=0; i<arrLength; i++) {
            let dName = event.target['dName' + i].value;
            let dType = event.target['dType' + i].value;
            let dVersion = event.target['dVersion' + i].value;
            try {
                res = await axios.get('/get/' + dType + '/' + dName);
            }
            catch(err) {
                this.setState({
                    errorAddingDependency: true,
                    modalShow: false,
                    loader: false
                })
            }
            if(res.data.length > 1) {
                wpPackageList.push(res.data.filter((obj) => obj.version == dVersion)[0]);
            }
            else {
                wpPackageList.push(res.data);
            }
        }

        let newPlugin = [{
            "name": event.target.name.value,
            "type": event.target.type.value,
            "isMandatory": event.target.isMandatory.checked ? 1 : 0,
            "isLicence": event.target.isLicence.checked ? 1 : 0,
            "version": event.target.version.value,
            "risk": event.target.risk.value,
            "minVersionWp": event.target.minVersionWp.value,
            "testedWp": event.target.testedWp.value,
            "isDependent": event.target.isDependent.checked ? 1 : 0,
            "wpPackageList": wpPackageList.length ? wpPackageList : null
        }];

        console.log(newPlugin);

        if(this.state.editPlugin) {
            console.log(event.target.id.value);

            axios.post('/post/plugin', newPlugin)
                .then(res => {
                    this.setState({
                        pluginEdited: true,
                        editPlugin: false,
                        modalShow: false,
                        loader: false
                    })
                })
                .catch((error) => {
                    this.setState({
                        errorEditingPlugin: true,
                        editPlugin: false,
                        modalShow: false,
                        loader: false
                    })
                });
        }
        else {
            axios.post('/post/plugin', newPlugin)
                .then(res => {
                    this.setState({
                        pluginAdded: true,
                        modalShow: false,
                        loader: false
                    })
                })
                .catch((error) => {
                    this.setState({
                        errorAddingPlugin: true,
                        modalShow: false,
                        loader: false
                    })
                });
        }
    }

    editHandler = (event) => {
        this.setState({
            loader: true
        });

        axios.get('/get/plugin/' + event.target.id)
            .then((response) => {
                this.setState({
                    editPlugin: true,
                    editPluginData: response.data,
                    modalShow: true,
                    loader: false
                })
            })
            .catch((error) => {
                this.setState({
                    error: "Error fetching data",
                    loader: false
                })
            });
    }

    deleteHandler = (event) => {
        this.setState({
            confirmModalShow: true,
            deletePlugin: true,
            deletePluginId: event.target.id
        })
    }

    pluginDeleteHandler = () => {
        this.setState({
            loader: true
        });

        console.log(this.state.deletePluginId);
        axios.post('/post/plugin1', this.state.deletePluginId)
            .then((response) => {
                this.setState({
                    pluginDeleted: true,
                    deletePlugin: false,
                    confirmModalShow: false,
                    loader: false
                })
            })
            .catch((error) => {
                this.setState({
                    errorDeletingPlugin: true,
                    deletePlugin: false,
                    confirmModalShow: false,
                    loader: false
                })
            });        
    }

    render() {
        const { classes } = this.props;

        // Alert
        let alert = null;
        if(this.state.error != '') {
            alert = <Alert 
                        alertType="danger" 
                        alertMsg={this.state.error}
                        dismissible={false}
                    />
        }
        else if(this.state.errorAddingPlugin) {
            alert = <Alert 
                        alertType="danger" 
                        alertMsg="Error: Failed to add new plugin"
                        dismissible
                        closeHandler={this.alertCloseHandler}
                    />
        }
        else if(this.state.pluginAdded) {
            alert = <Alert 
                        alertType="success" 
                        alertMsg="Success: Added new plugin"
                        dismissible
                        closeHandler={this.alertCloseHandler}
                    />
        }
        else if(this.state.errorEditingPlugin) {
            alert = <Alert 
                        alertType="danger" 
                        alertMsg="Error: Failed to update the plugin"
                        dismissible
                        closeHandler={this.alertCloseHandler}
                    />
        }
        else if(this.state.pluginEdited) {
            alert = <Alert 
                        alertType="success" 
                        alertMsg="Success: Updated the plugin"
                        dismissible
                        closeHandler={this.alertCloseHandler}
                    />
        }
        else if(this.state.errorDeletingPlugin) {
            alert = <Alert 
                        alertType="danger" 
                        alertMsg="Error: Failed to delete the plugin"
                        dismissible
                        closeHandler={this.alertCloseHandler}
                    />
        }
        else if(this.state.pluginDeleted) {
            alert = <Alert 
                        alertType="success" 
                        alertMsg="Success: Deleted the plugin"
                        dismissible
                        closeHandler={this.alertCloseHandler}
                    />
        }
        else if(this.state.errorAddingDependency) {
            alert = <Alert 
                        alertType="danger" 
                        alertMsg="Error: Please verify the dependency values"
                        dismissible
                        closeHandler={this.alertCloseHandler}
                    />
        }
        else {
            alert = null;
        }

        // Form action
        let modalHeaderTxt = 'Add Plugin';
        let pluginFormAction = 'add'
        if(this.state.editPlugin) {
            modalHeaderTxt = 'Edit Plugin';
            pluginFormAction = 'edit'
        }

        return (
            <div>
                <Button btnType="button"
                    btnName="Add" 
                    withIcon
                    icon="plus" 
                    btnClass="btn sm btn-secondary" 
                    clickHandler={this.modalOpenHandler}
                />
                <hr />
                {alert}
                <div className="row">
                    <div className="col-xs-12 table-responsive">
                        <table className="table">
                            <Thead columns={this.pluginColumns} />
                            <tbody>
                                {this.state.data.map((obj) => {
                                    return (
                                        <tr key={obj.id}>
                                            <td>{obj.name}</td>
                                            <td>{obj.type}</td>
                                            <td>{obj.isMandatory}</td>
                                            <td>{obj.isLicence}</td>
                                            <td>{obj.version}</td>
                                            <td>{obj.risk}</td>
                                            <td>{obj.minVersionWp}</td>
                                            <td>{obj.testedWp}</td>
                                            <td>{obj.isDependent}</td>
                                            <td>
                                                {obj.wpPackageList ? obj.wpPackageList.map((ele, i) => {
                                                    return (
                                                        <ExpansionPanel key={i} className={classes.expansionPanel}>
                                                            <ExpansionPanelSummary className={classes.expansionPanelSummary}>
                                                                <p className={classes.expansionPanelP}><strong>Name: </strong>{ele.name}</p>
                                                            </ExpansionPanelSummary>
                                                            <ExpansionPanelDetails className={classes.expansionPanelDetails}>
                                                                <p className={classes.expansionPanelP}><strong>Type: </strong>{ele.type}</p>
                                                                <p></p>
                                                                <p className={classes.expansionPanelP}><strong>Version: </strong>{ele.version}</p>
                                                                <p></p>
                                                            </ExpansionPanelDetails>
                                                        </ExpansionPanel>
                                                    )
                                                }) : null}
                                            </td>
                                            <td>
                                                <a id={obj.id} onClick={this.editHandler}>Edit</a>
                                                <p></p>
                                                <a id={obj.id} onClick={this.deleteHandler}>Delete</a>
                                            </td>
                                        </tr>
                                    )
                                })}
                            </tbody>
                        </table>
                    </div>
                </div>
                <Modal
                    headerTxt={modalHeaderTxt}
                    show={this.state.modalShow}
                    close={this.modalCloseHandler}
                    modalFormHandler={this.pluginFormHandler}
                    formName="add-edit-plugin"
                    formAction={pluginFormAction}
                    pluginData={this.state.editPluginData}
                    resetForm={this.state.resetForm}
                />
                <ConfirmModal
                    show={this.state.confirmModalShow}
                    close={this.confirmModalCloseHandler}
                    content="plugin"
                    confirmHandler={this.pluginDeleteHandler}
                />
                <PageLoader show={this.state.loader} />
            </div>
        );        
    }
}

export default withStyles(styles)(plugins);