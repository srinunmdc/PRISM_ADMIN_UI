import React from 'react';

import Button from '../../ui/button/button';

const coreForm = (props) => {
    let isLicenceVal = props.formAction == 'edit' ? props.coreData.isLicence : 0;
    let btnTxt = props.formAction == 'edit' ? 'Update' : 'Submit';

    return (
        <form key={props.formAction} id="core-form" className="form-horizontal" onSubmit={props.formHandler}>
            <div className="form-group">
                <label className="col-sm-2 control-label">Name</label>
                <div className="col-sm-8"> 
                    <input className="form-control input-xsm" 
                        type="text" 
                        name="name" 
                        required
                        defaultValue={props.formAction == 'edit' ? props.coreData.name : ''}
                    />
                </div>
            </div>
            <div className="form-group">
                <label className="col-sm-2 control-label">Type</label>
                <div className="col-sm-8"> 
                    <input className="form-control input-xsm" 
                        type="text" 
                        value="core" 
                        disabled 
                        name="type"
                    />
                </div>
            </div>
            <div className="form-group">
                <label className="col-sm-2 control-label"></label>
                <div className="col-sm-8">
                    <label className="di-checkbox">
                        <input className="sm" 
                            type="checkbox" 
                            name="isLicence" 
                            defaultChecked={isLicenceVal ? true : false}
                        />
                        <span className="lbl sm">Is Licence</span>
                    </label>
                </div>
            </div>
            <div className="form-group">
                <label className="col-sm-2 control-label">Version</label>
                <div className="col-sm-8"> 
                    <input className="form-control input-xsm" 
                        type="text" 
                        name="version" 
                        required
                        defaultValue={props.formAction == 'edit' ? props.coreData.version : ''}
                    />
                </div>
            </div>
            <div className="form-group">
                <label className="col-sm-2 control-label">Risk</label>
                <div className="col-sm-8"> 
                    <input className="form-control input-xsm" 
                        type="text" 
                        name="risk" 
                        required
                        defaultValue={props.formAction == 'edit' ? props.coreData.risk : ''}
                    />
                </div>
            </div>
            <div className="form-group hide">
                <label className="col-sm-2 control-label">Id</label>
                <div className="col-sm-8"> 
                    <input className="form-control input-xsm" 
                        type="text" 
                        name="id" 
                        defaultValue={props.formAction == 'edit' ? props.coreData.id : ''}
                    />
                </div>
            </div>
            <div className="form-group">
                <label className="col-sm-2 control-label"></label>
                <div className="col-sm-8">
                    <Button btnType="submit"
                        btnName={btnTxt}
                        btnClass="btn btn-primary"
                    />
                </div>
            </div>
        </form>
    )
}

export default coreForm;