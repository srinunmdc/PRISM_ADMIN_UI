import React, {Component} from 'react';

import Button from '../../ui/button/button';
import classes from './plugin-form.css';

class pluginForm extends Component {
    state = {
        dependencyArr: [],
        dNameArr: [],
        dTypeArr: [],
        dVersionArr: [],
        isDependentChecked: false
    }

    componentWillReceiveProps(nextProps) {
        if(nextProps.formAction != this.props.formAction) {
            if (nextProps.formAction == 'edit') {
                let dependencyArr = [];
                let dNameArr = [];
                let dTypeArr = [];
                let dVersionArr = [];
                dependencyArr = nextProps.pluginData.wpPackageList == null ? [] : nextProps.pluginData.wpPackageList;
                if(dependencyArr !== null && dependencyArr.length) {
                    for(let obj of dependencyArr) {
                        dNameArr.push(obj.name);
                        dTypeArr.push(obj.type);
                        dVersionArr.push(obj.version);
                    }
                }
                this.setState({
                    dependencyArr: [...dependencyArr],
                    dNameArr: [...dNameArr],
                    dTypeArr: [...dTypeArr],
                    dVersionArr: [...dVersionArr],
                    isDependentChecked: nextProps.pluginData.isDependent ? true : false
                });
            }
            if (nextProps.formAction == 'add') {
                this.setState({
                    dependencyArr: [],
                    dNameArr: [],
                    dTypeArr: [],
                    dVersionArr: [],
                    isDependentChecked: false
                });
            }
        }
    }

    addDependency = () => {
        this.setState({
            dependencyArr: [...this.state.dependencyArr, '']
        })
    }

    handleDNameChange = (e, i) => {
        let newArr = [...this.state.dNameArr];
        newArr[i] = e.target.value;
        this.setState({
            dNameArr: [...newArr]
        })
    }

    handleDTypeChange = (e, i) => {
        let newArr = [...this.state.dTypeArr];
        newArr[i] = e.target.value;
        this.setState({
            dTypeArr: [...newArr]
        })
    }

    handleDVersionChange = (e, i) => {
        let newArr = [...this.state.dVersionArr];
        newArr[i] = e.target.value;
        this.setState({
            dVersionArr: [...newArr]
        })
    }

    handleIsDependentChange = (e) => {
        this.setState({
            isDependentChecked: e.target.checked,
            dependencyArr: []
        });
    }

    handleRemove(i) {
        let newArr = [...this.state.dependencyArr];
        newArr.splice(i, 1);
        this.setState({
            dependencyArr: [...newArr] 
        })
    }

    render() {
        let isLicenceVal = this.props.formAction == 'edit' ? this.props.pluginData.isLicence : 0;
        let isMandatoryVal = this.props.formAction == 'edit' ? this.props.pluginData.isMandatory : 0;
        let isDependentBlockClass = this.state.isDependentChecked ? 'show' : 'hide';
        let btnTxt = this.props.formAction == 'edit' ? 'Update' : 'Submit';

        return (
            <form key={this.props.formAction} 
                id="plugin-form" 
                className="form-horizontal" 
                onSubmit={(e) => {e.persist();this.props.formHandler(e, this.state.dependencyArr.length)}}
            >
                <div className="form-group">
                    <label className="col-sm-3 control-label">Name</label>
                    <div className="col-sm-8"> 
                        <input className="form-control input-xsm" 
                            type="text" 
                            name="name" 
                            required
                            defaultValue={this.props.formAction == 'edit' ? this.props.pluginData.name : ''}
                        />
                    </div>
                </div>
                <div className="form-group">
                    <label className="col-sm-3 control-label">Type</label>
                    <div className="col-sm-8"> 
                        <input className="form-control input-xsm" 
                            type="text" 
                            value="plugin" 
                            disabled 
                            name="type"
                        />
                    </div>
                </div>
                <div className="form-group">
                    <label className="col-sm-3 control-label"></label>
                    <div className="col-sm-8">
                        <label className="di-checkbox">
                            <input className="sm" 
                                type="checkbox" 
                                name="isMandatory" 
                                defaultChecked={isMandatoryVal ? true : false}
                            />
                            <span className="lbl sm">Is Mandatory</span>
                        </label>
                        <label className="di-checkbox">
                            <input className="sm" 
                                type="checkbox" 
                                name="isLicence" 
                                defaultChecked={isLicenceVal ? true : false}
                            />
                            <span className="lbl sm">Is Licence</span>
                        </label>
                    </div>
                </div>
                <div className="form-group">
                    <label className="col-sm-3 control-label">Version</label>
                    <div className="col-sm-8"> 
                        <input className="form-control input-xsm" 
                            type="text" 
                            name="version" 
                            required
                            defaultValue={this.props.formAction == 'edit' ? this.props.pluginData.version : ''}
                        />
                    </div>
                </div>
                <div className="form-group">
                    <label className="col-sm-3 control-label">Risk</label>
                    <div className="col-sm-8"> 
                        <input className="form-control input-xsm" 
                            type="text" 
                            name="risk" 
                            required
                            defaultValue={this.props.formAction == 'edit' ? this.props.pluginData.risk : ''}
                        />
                    </div>
                </div>
                <div className="form-group">
                    <label className="col-sm-3 control-label">Min Version WP</label>
                    <div className="col-sm-8"> 
                        <input className="form-control input-xsm" 
                            type="text" 
                            name="minVersionWp" 
                            required
                            defaultValue={this.props.formAction == 'edit' ? this.props.pluginData.minVersionWp : ''}
                        />
                    </div>
                </div>
                <div className="form-group">
                    <label className="col-sm-3 control-label">Tested WP</label>
                    <div className="col-sm-8"> 
                        <input className="form-control input-xsm" 
                            type="text" 
                            name="testedWp" 
                            required
                            defaultValue={this.props.formAction == 'edit' ? this.props.pluginData.testedWp : ''}
                        />
                    </div>
                </div>
                <div className="form-group">
                    <label className="col-sm-3 control-label"></label>
                    <div className="col-sm-8">
                        <label className="di-checkbox">
                            <input className="sm" 
                                type="checkbox" 
                                name="isDependent" 
                                checked={this.state.isDependentChecked}
                                onChange={this.handleIsDependentChange}
                            />
                            <span className="lbl sm">Is Dependent</span>
                        </label>
                    </div>
                </div>
                <div id="dependencies" className={isDependentBlockClass}>
                    {
                        this.state.dependencyArr.map((dependency, i) => {
                            return (
                                <div key={i}>
                                    <div className="form-group">
                                        <label className="col-sm-3 control-label">Name</label>
                                        <div className="col-sm-8"> 
                                            <input className="form-control input-xsm" 
                                                type="text" 
                                                name={"dName" + i} 
                                                required
                                                value={this.state.dNameArr[i] || ''} 
                                                onChange={(e) => this.handleDNameChange(e, i)}
                                            />
                                        </div>
                                    </div>
                                    <div className="form-group">
                                        <label className="col-sm-3 control-label">Type</label>
                                        <div className="col-sm-8"> 
                                            <input className="form-control input-xsm" 
                                                type="text" 
                                                name={"dType" + i} 
                                                required
                                                value={this.state.dTypeArr[i] || ''} 
                                                onChange={(e) => this.handleDTypeChange(e, i)}
                                            />
                                        </div>
                                    </div>
                                    <div className="form-group">
                                        <label className="col-sm-3 control-label">Version</label>
                                        <div className="col-sm-8"> 
                                            <input className="form-control input-xsm" 
                                                type="text" 
                                                name={"dVersion" + i}
                                                required
                                                value={this.state.dVersionArr[i] || ''} 
                                                onChange={(e) => this.handleDVersionChange(e, i)}
                                            />
                                        </div>
                                    </div>
                                    <div className="form-group removeDependency-link text-right">
                                        <label className="col-sm-2 control-label"></label>
                                        <div className="col-sm-8">
                                            <a onClick={() => this.handleRemove(i)}>Remove</a>
                                        </div>
                                    </div>
                                </div>
                            )
                        })
                    }
                    <div className="form-group addDependency-link">
                        <label className="col-sm-3 control-label"></label>
                        <div className="col-sm-8">
                            <a onClick={this.addDependency}>Add</a>
                        </div>
                    </div>
                </div>
                <div className="form-group hide">
                    <label className="col-sm-3 control-label">Id</label>
                    <div className="col-sm-8"> 
                        <input className="form-control input-xsm" 
                            type="text" 
                            name="id" 
                            defaultValue={this.props.formAction == 'edit' ? this.props.pluginData.id : ''}
                        />
                    </div>
                </div>
                <div className="form-group">
                    <label className="col-sm-3 control-label"></label>
                    <div className="col-sm-8">
                        <Button btnType="submit"
                            btnName={btnTxt}
                            btnClass="btn btn-primary"
                        />
                    </div>
                </div>
            </form>
        )
    }
}

export default pluginForm;