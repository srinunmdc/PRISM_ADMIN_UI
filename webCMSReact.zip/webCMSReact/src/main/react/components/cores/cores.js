import React, { Component } from 'react';

import Button from '../ui/button/button';
import Thead from '../ui/table/table-head/table-head';
import Modal from '../ui/modal/modal';
import Alert from '../ui/alert/alert';
import ConfirmModal from '../ui/modal/confirm-modal/confirm-modal';
import PageLoader from '../ui/loader/page-loader/page-loader';
import axios from '../../axios';

class cores extends Component {
    state = {
        modalShow: false,
        confirmModalShow: false,
        loader: false,
        data: [],
        error: '',
        coreAdded: false,
        errorAddingCore: false,
        editCore: false,
        editCoreData: [],
        coreEdited: false,
        errorEditingCore: false,
        deleteCore: false,
        deleteCoreId: null,
        coreDeleted: false,
        errorDeletingCore: false
    }

    componentDidMount() {
        this.setState({
            loader: true
        });

        axios.get('/get/core')
            .then((response) => {
                this.setState({
                    data: response.data,
                    loader: false
                })
            })
            .catch((error) => {
                this.setState({
                    error: "Error fetching data",
                    loader: false
                })
            });
    }

    coreColumns = ['Name', 'Type', 'Is Licence', 'Version', 'Risk', ' '];

    modalOpenHandler = () => {
        this.setState({
            modalShow: true
        })
    };

    modalCloseHandler = () => {
        this.setState({
            modalShow: false,
            editCore: false
        })
    };

    confirmModalOpenHandler = () => {
        this.setState({
            confirmModalShow: true
        })
    };

    confirmModalCloseHandler = () => {
        this.setState({
            confirmModalShow: false
        })
    };

    alertCloseHandler = () => {
        this.setState({
            coreAdded: false,
            errorAddingCore: false,
            editCore: false,
            coreEdited: false,
            errorEditingCore: false,
            deleteCore: false,
            coreDeleted: false,
            errorDeletingCore: false
        })        
    }

    coreFormHandler = (event) => {
        event.preventDefault();

        this.setState({
            loader: true
        });

        let newCore = [{
            "name": event.target.name.value,
            "type": event.target.type.value,
            "isLicence": event.target.isLicence.checked ? 1 : 0,
            "version": event.target.version.value,
            "risk": event.target.risk.value
        }];

        console.log(newCore);

        if(this.state.editCore) {
            console.log(event.target.id.value);

            axios.post('/post/core', newCore)
                .then(res => {
                    this.setState({
                        coreEdited: true,
                        editCore: false,
                        modalShow: false,
                        loader: false
                    })
                })
                .catch((error) => {
                    this.setState({
                        errorEditingCore: true,
                        editCore: false,
                        modalShow: false,
                        loader: false,
                    })
                });
        }
        else {
            axios.post('/post/core', newCore)
                .then(res => {
                    console.log(res.data);
                    this.setState({
                        coreAdded: true,
                        modalShow: false,
                        loader: false
                    })
                })
                .catch((error) => {
                    console.log(error);
                    this.setState({
                        errorAddingCore: true,
                        modalShow: false,
                        loader: false
                    })
                });
        }
    }

    editHandler = (event) => {
        this.setState({
            loader: true
        });

        axios.get('/get/core/' + event.target.id)
            .then((response) => {
                this.setState({
                    editCore: true,
                    editCoreData: response.data,
                    modalShow: true,
                    loader: false
                })
            })
            .catch((error) => {
                this.setState({
                    error: "Error fetching data",
                    loader: false
                })
            });
    }

    deleteHandler = (event) => {
        this.setState({
            confirmModalShow: true,
            deleteCore: true,
            deleteCoreId: event.target.id
        })
    }

    coreDeleteHandler = () => {
        this.setState({
            loader: true
        });

        console.log(this.state.deleteCoreId);
        axios.post('/post/core1', this.state.deleteCoreId)
            .then((response) => {
                this.setState({
                    coreDeleted: true,
                    deleteCore: false,
                    confirmModalShow: false,
                    loader: false
                })
            })
            .catch((error) => {
                this.setState({
                    errorDeletingCore: true,
                    deleteCore: false,
                    confirmModalShow: false,
                    loader: false
                })
            });        
    }

    render() {
        // Alert
        let alert = null;
        if(this.state.error != '') {
            alert = <Alert 
                        alertType="danger" 
                        alertMsg={this.state.error}
                        dismissible={false}
                    />
        }
        else if(this.state.errorAddingCore) {
            alert = <Alert 
                        alertType="danger" 
                        alertMsg="Error: Failed to add new core"
                        dismissible
                        closeHandler={this.alertCloseHandler}
                    />
        }
        else if(this.state.coreAdded) {
            alert = <Alert 
                        alertType="success" 
                        alertMsg="Success: Added new core"
                        dismissible
                        closeHandler={this.alertCloseHandler}
                    />
        }
        else if(this.state.errorEditingCore) {
            alert = <Alert 
                        alertType="danger" 
                        alertMsg="Error: Failed to update the core"
                        dismissible
                        closeHandler={this.alertCloseHandler}
                    />
        }
        else if(this.state.coreEdited) {
            alert = <Alert 
                        alertType="success" 
                        alertMsg="Success: Updated the core"
                        dismissible
                        closeHandler={this.alertCloseHandler}
                    />
        }
        else if(this.state.errorDeletingCore) {
            alert = <Alert 
                        alertType="danger" 
                        alertMsg="Error: Failed to delete the core"
                        dismissible
                        closeHandler={this.alertCloseHandler}
                    />
        }
        else if(this.state.coreDeleted) {
            alert = <Alert 
                        alertType="success" 
                        alertMsg="Success: Deleted the core"
                        dismissible
                        closeHandler={this.alertCloseHandler}
                    />
        }
        else {
            alert = null;
        }

        // Form action
        let modalHeaderTxt = 'Add Core';
        let coreFormAction = 'add'
        if(this.state.editCore) {
            modalHeaderTxt = 'Edit Core';
            coreFormAction = 'edit'
        }

        return (
            <div>
                <Button btnType="button"
                    btnName="Add" 
                    withIcon
                    icon="plus" 
                    btnClass="btn sm btn-secondary" 
                    clickHandler={this.modalOpenHandler}
                />
                <hr />
                {alert}
                <div className="row">
                    <div className="col-xs-12 table-responsive">
                        <table className="table">
                            <Thead columns={this.coreColumns} />
                            <tbody>
                                {this.state.data.map((obj) => {
                                    return (
                                        <tr key={obj.id}>
                                            <td>{obj.name}</td>
                                            <td>{obj.type}</td>
                                            <td>{obj.isLicence}</td>
                                            <td>{obj.version}</td>
                                            <td>{obj.risk}</td>
                                            <td>
                                                <a id={obj.id} onClick={this.editHandler}>Edit</a>
                                                <p></p>
                                                <a id={obj.id} onClick={this.deleteHandler}>Delete</a>
                                            </td>
                                        </tr>
                                    )
                                })}
                            </tbody>
                        </table>
                    </div>
                </div>
                <Modal
                    headerTxt={modalHeaderTxt}
                    show={this.state.modalShow}
                    close={this.modalCloseHandler}
                    modalFormHandler={this.coreFormHandler}
                    formName="add-edit-core"
                    formAction={coreFormAction}
                    coreData={this.state.editCoreData}
                />
                <ConfirmModal
                    show={this.state.confirmModalShow}
                    close={this.confirmModalCloseHandler}
                    content="core"
                    confirmHandler={this.coreDeleteHandler}
                />
                <PageLoader show={this.state.loader} />
            </div>
        );        
    }
}

export default cores;