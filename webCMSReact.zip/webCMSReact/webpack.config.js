var path = require('path');

module.exports = {
    entry: {
        main: './src/main/react/index.js'
    },
    output: {
        path: path.resolve(__dirname, './src/main/webapp/js/react-build'),
        filename: 'bundle.js'
    },
    module: {
        rules: [
            {
                test: /\.js$/,
                exclude: /(node_modules)/,
                use: {
                    loader: 'babel-loader'
                }
            },
            {
                test: /\.css$/,
                exclude: /(node_modules)/,
                loader: 'style-loader!css-loader'
            }
        ]
    },
    stats: {
        colors: true
    },
    devtool: 'source-map',
    mode: 'production'
};
